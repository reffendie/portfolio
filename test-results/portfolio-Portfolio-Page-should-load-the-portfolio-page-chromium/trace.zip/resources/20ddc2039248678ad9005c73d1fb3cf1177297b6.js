import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/royeffendie/Projects/portfolio/src/styles/index.css"
const __vite__css = "* {\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n}\n\n:root {\n  --primary: #2563eb;\n  --text: #1e293b;\n  --text-light: #64748b;\n  --border: #e2e8f0;\n  --bg-light: #f8fafc;\n}\n\nbody {\n  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  color: var(--text);\n  line-height: 1.6;\n}\n\na {\n  color: var(--primary);\n  text-decoration: none;\n}\n\na:hover {\n  text-decoration: underline;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))