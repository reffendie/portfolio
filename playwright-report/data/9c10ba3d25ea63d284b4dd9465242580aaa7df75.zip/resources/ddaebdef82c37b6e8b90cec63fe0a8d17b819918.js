import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Portfolio.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6df16263"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6df16263"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import "/src/components/Portfolio.css";
const Portfolio = () => {
  return /* @__PURE__ */ jsxDEV("div", { className: "portfolio", children: /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "header", children: /* @__PURE__ */ jsxDEV("div", { className: "header-content", children: [
      /* @__PURE__ */ jsxDEV("h1", { children: "Roy Effendie, BA., MSc." }, void 0, false, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 31,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "title", children: "Senior Technical Program Manager" }, void 0, false, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 32,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
      lineNumber: 30,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "summary", children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Technical Program Manager with ",
      /* @__PURE__ */ jsxDEV("strong", { children: "22+ years" }, void 0, false, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 39,
        columnNumber: 44
      }, this),
      " delivering complex, cross-functional programs in fintech, AI, and enterprise systems. Proven track record managing ",
      /* @__PURE__ */ jsxDEV("strong", { children: "$100M+ programs" }, void 0, false, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 40,
        columnNumber: 42
      }, this),
      ", leading global teams of ",
      /* @__PURE__ */ jsxDEV("strong", { children: "50+ members" }, void 0, false, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 40,
        columnNumber: 100
      }, this),
      ", and driving measurable business impact through strategic technical leadership. Expert at bridging business and engineering teams while orchestrating multiple high-stakes initiatives simultaneously."
    ] }, void 0, true, {
      fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
      lineNumber: 38,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "two-column", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "left-column", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "section", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Experience Highlights" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 53,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "experience-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exp-header", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Sr. Director of DevOps/Platform Engineering" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 57,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "year", children: "2025-Present" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 58,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 56,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "company", children: "Uniphore, Palo Alto, CA" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 60,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Led post-acquisition infrastructure consolidation of two companies, standardizing CI/CD pipelines and platform tooling across the organization" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 62,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Partnered cross-functionally with Product, Sales, Delivery, and Infosec to scale deployments across 3 global regions (US, UK, Middle East)" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 63,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Drove adoption of standard KPIs and tools, improving schedule predictability and accelerating release velocity by 20%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 64,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Facilitated collaborative planning sessions across business and technical stakeholders, reducing cross-team dependencies and improving milestone accuracy by 25%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 65,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Optimized cloud spend by identifying inefficiencies, reducing AWS costs by $400K annually while cutting operational costs by 15%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 66,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 61,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 55,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "experience-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exp-header", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Sr. Director of Customer Solutions" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 72,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "year", children: "2022-2025" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 73,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 71,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "company", children: "Infoworks (Acquired by Uniphore)" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 75,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Directed development of SaaS AI solutions leveraging OpenAI LLMs to automate SQL generation from natural language, transforming enterprise data workflows" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 77,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Collaborated with Fortune 500 customers to design and deliver data ingestion and pipeline automation solutions, accelerating development by 80% and increasing adoption by 40%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 78,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Led Customer Engineering team in building Python SDKs and automation scripts, accelerating customer onboarding by 2x" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 79,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Established KPIs and operational processes for Customer Engineering, Professional Services, and Field-Testing, improving issue resolution times by 35%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 80,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Managed vendor selection and contracts, achieving 95% customer renewal rate worth $15M while cutting third-party costs by 20%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 81,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 76,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 70,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "experience-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exp-header", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Sr. Technical Program Manager" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 87,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "year", children: "2021-2022" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 88,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 86,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "company", children: "Velo Labs, San Francisco, CA" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 90,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Owned end-to-end program management of cross-border payments platform leveraging blockchain technology, enabling faster, lower-cost transactions across 4+ countries" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 92,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Defined and executed product roadmap in partnership with C-level executives, aligning engineering, compliance, and business teams to deliver strategic goals" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 93,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Scaled and led global team of 30+ engineers and product managers, establishing agile practices and improving on-time delivery of key releases by 50%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 94,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Drove partner integrations by defining technical scope and leading automation initiatives that reduced settlement times by 70% and increased partner adoption by 25%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 95,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Designed and led migration of financial partners to Stellar blockchain ecosystem, cutting integration timelines from 8 months to 4 weeks" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 96,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 91,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 85,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "experience-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exp-header", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Senior Manager" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 102,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "year", children: "2010-2021" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 103,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 101,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "company", children: "Ernst & Young, Seattle, WA" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 105,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Led successful implementation of the largest personal auto policy transformation program in Canada worth $70M, overseeing 300+ integrations across auto insurance platforms, vehicle registration and licensing systems" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 107,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Program success resulted in additional scope to transform commercial auto, generating $32M of new consulting revenue for EY" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 108,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Directed claims data conversion and batch integration projects at large US insurers, enabling seamless migration of millions of customer records and managing $15M of consulting revenue" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 109,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Developed EY's Guidewire Global Delivery Methodology, training hundreds of consultants worldwide and establishing scalable standard for implementations" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 110,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Pioneered solutions leveraging blockchain, IoT, and microservices to support innovation initiatives across insurance clients, generating $5M new consulting revenue in first year" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 111,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 106,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 100,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "experience-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exp-header", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Technical Architect & Consultant" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 117,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "year", children: "2002-2010" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 118,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 116,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "company", children: "Sezmi, Accenture, BearingPoint" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 120,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Architected and delivered enterprise CRM, billing, and video-on-demand platforms supporting 100K+ subscribers" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 122,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Designed and built middleware systems to provision digital keys for movie purchases, reducing provisioning errors by 80%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 123,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Led integration of Siebel CRM with Citrix legacy systems, improving customer data visibility across 20+ business units" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 124,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Directed multiple data migration projects, consolidating legacy systems and saving clients $8M+ in IT costs while reducing project timelines by 30%" }, void 0, false, {
                fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
                lineNumber: 125,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 121,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 115,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
          lineNumber: 52,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "section", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Education & Certifications" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 132,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "education-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "M.Sc. Database Development & Administration" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 134,
              columnNumber: 17
            }, this),
            " — Golden Gate University"
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 133,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "education-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "B.A. Economics" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 137,
              columnNumber: 17
            }, this),
            " — Parahyangan Catholic University"
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 136,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "education-item", children: /* @__PURE__ */ jsxDEV("strong", { children: "AWS Certified Cloud Practitioner" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 140,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 139,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
          lineNumber: 131,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 49,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "right-column", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "section", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Core Strengths" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 151,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "strength-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🎯 Multi-Project Orchestration" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 153,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Successfully managed 300+ concurrent integrations across enterprise platforms" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 154,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 152,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "strength-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🤖 AI-Driven Innovation" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 157,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Leveraged OpenAI/LLMs to accelerate development by 80% and improve productivity" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 158,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 156,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "strength-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🌉 Business-Tech Bridge" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 161,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Partner across Product, Engineering, Sales, and C-suite to align strategic initiatives" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 162,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 160,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "strength-item", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "⚡ Fast Learner" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 165,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Diverse background in database, web dev, and system integration. Quickly master new technologies" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 166,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 164,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
          lineNumber: 150,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "section", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Technical Skills" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 172,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Cloud & Infrastructure:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 175,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "AWS, Azure, GCP, Kubernetes, Docker, CI/CD" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 176,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 174,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "AI & Data:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 180,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "OpenAI/LLMs, Snowflake, Databricks, Kafka, Spark" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 181,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 179,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Blockchain:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 185,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Stellar, BSC, Web3, Smart Contracts" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 186,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 184,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Development:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 190,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Python, JavaScript, React, Node.js, Golang, SQL" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 191,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 189,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Databases:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 195,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Oracle, SQL Server, PostgreSQL, NoSQL" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 196,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 194,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-group", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "PM Tools:" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 200,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "JIRA, Confluence, Agile/Scrum, MS Project" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 201,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 199,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
          lineNumber: 171,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "section target-role", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Seeking" }, void 0, false, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 207,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Senior TPM roles at $225K+" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 209,
              columnNumber: 17
            }, this),
            " in tech companies where I can drive strategic technical initiatives, orchestrate complex cross-functional programs, and deliver measurable business impact at scale."
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 208,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "cta-buttons", children: [
            /* @__PURE__ */ jsxDEV("a", { href: "mailto:reffendie@outlook.com", className: "btn-primary", children: "Email Me" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 214,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "https://www.linkedin.com/in/reffendie/", target: "_blank", rel: "noopener noreferrer", className: "btn-secondary", children: "LinkedIn" }, void 0, false, {
              fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
              lineNumber: 215,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
            lineNumber: 213,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
          lineNumber: 206,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
        lineNumber: 147,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
      lineNumber: 46,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
    lineNumber: 26,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx",
    lineNumber: 25,
    columnNumber: 5
  }, this);
};
_c = Portfolio;
export default Portfolio;
var _c;
$RefreshReg$(_c, "Portfolio");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/royeffendie/Projects/portfolio/src/components/Portfolio.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYWixPQUFPQSxXQUFXO0FBQ2xCLE9BQU87QUFFUCxNQUFNQyxZQUFZQSxNQUFNO0FBQ3RCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLGFBR2I7QUFBQSwyQkFBQyxZQUFPLFdBQVUsVUFDaEIsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsNkJBQUMsUUFBRyx1Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsTUFDM0IsdUJBQUMsT0FBRSxXQUFVLFNBQVEsZ0RBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUdBLHVCQUFDLGFBQVEsV0FBVSxXQUNqQixpQ0FBQyxPQUFDO0FBQUE7QUFBQSxNQUMrQix1QkFBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUFTO0FBQUEsTUFDNUIsdUJBQUMsWUFBTywrQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFBUztBQUFBLE1BQTBCLHVCQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQVM7QUFBQSxTQUZySDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxjQUdiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBR2I7QUFBQSwrQkFBQyxhQUFRLFdBQVUsV0FDakI7QUFBQSxpQ0FBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsVUFFekIsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsY0FDbkQsdUJBQUMsVUFBSyxXQUFVLFFBQU8sNEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsaUJBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxXQUFVLHVDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hELHVCQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLDhKQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtKO0FBQUEsY0FDbEosdUJBQUMsUUFBRywwSkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4STtBQUFBLGNBQzlJLHVCQUFDLFFBQUcscUlBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUg7QUFBQSxjQUN6SCx1QkFBQyxRQUFHLGdMQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9LO0FBQUEsY0FDcEssdUJBQUMsUUFBRyxnSkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvSTtBQUFBLGlCQUx0STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFlBQU8sa0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxjQUMxQyx1QkFBQyxVQUFLLFdBQVUsUUFBTyx5QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQVUsZ0RBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcseUtBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNko7QUFBQSxjQUM3Six1QkFBQyxRQUFHLDhMQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtMO0FBQUEsY0FDbEwsdUJBQUMsUUFBRyxvSUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SDtBQUFBLGNBQ3hILHVCQUFDLFFBQUcsc0tBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEo7QUFBQSxjQUMxSix1QkFBQyxRQUFHLDZJQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlJO0FBQUEsaUJBTG5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsWUFBTyw2Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGNBQ3JDLHVCQUFDLFVBQUssV0FBVSxRQUFPLHlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsV0FBVSw0Q0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxRQUNDO0FBQUEscUNBQUMsUUFBRyxvTEFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SztBQUFBLGNBQ3hLLHVCQUFDLFFBQUcsNEtBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0s7QUFBQSxjQUNoSyx1QkFBQyxRQUFHLG9LQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdKO0FBQUEsY0FDeEosdUJBQUMsUUFBRyxvTEFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SztBQUFBLGNBQ3hLLHVCQUFDLFFBQUcsd0pBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEk7QUFBQSxpQkFMOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxZQUFPLDhCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNCO0FBQUEsY0FDdEIsdUJBQUMsVUFBSyxXQUFVLFFBQU8seUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxXQUFVLDBDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25ELHVCQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLHVPQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJOO0FBQUEsY0FDM04sdUJBQUMsUUFBRywySUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErSDtBQUFBLGNBQy9ILHVCQUFDLFFBQUcsd01BQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEw7QUFBQSxjQUM1TCx1QkFBQyxRQUFHLHVLQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJKO0FBQUEsY0FDM0osdUJBQUMsUUFBRyxpTUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxTDtBQUFBLGlCQUx2TDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFlBQU8sZ0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN4Qyx1QkFBQyxVQUFLLFdBQVUsUUFBTyx5QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQVUsOENBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsWUFDdkQsdUJBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcsNkhBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUg7QUFBQSxjQUNqSCx1QkFBQyxRQUFHLHdJQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRIO0FBQUEsY0FDNUgsdUJBQUMsUUFBRyxzSUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwSDtBQUFBLGNBQzFILHVCQUFDLFFBQUcsbUtBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUo7QUFBQSxpQkFKeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0RUE7QUFBQSxRQUdBLHVCQUFDLGFBQVEsV0FBVSxXQUNqQjtBQUFBLGlDQUFDLFFBQUcsMENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxVQUM5Qix1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxZQUFPLDJEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFBUztBQUFBLGVBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFlBQU8sOEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUFTO0FBQUEsZUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFlBQU8sZ0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0E3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStGQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGdCQUdiO0FBQUEsK0JBQUMsYUFBUSxXQUFVLFdBQ2pCO0FBQUEsaUNBQUMsUUFBRyw4QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQ2xCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFlBQU8sOENBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxPQUFFLDZGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsZUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsWUFBTyx1Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQy9CLHVCQUFDLE9BQUUsK0ZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxlQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxZQUFPLHVDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsWUFDL0IsdUJBQUMsT0FBRSxzR0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RjtBQUFBLGVBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFlBQU8sOEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUN0Qix1QkFBQyxPQUFFLGdIQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HO0FBQUEsZUFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdBLHVCQUFDLGFBQVEsV0FBVSxXQUNqQjtBQUFBLGlDQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0I7QUFBQSxVQUVwQix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFlBQU8sdUNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUMvQix1QkFBQyxPQUFFLDBEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsZUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsWUFDbEIsdUJBQUMsT0FBRSxnRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLGVBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQ25CLHVCQUFDLE9BQUUsbURBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxlQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFlBQU8sNEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxZQUNwQix1QkFBQyxPQUFFLCtEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsZUFGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsWUFDbEIsdUJBQUMsT0FBRSxxREFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QztBQUFBLGVBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsWUFBTyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQ2pCLHVCQUFDLE9BQUUseURBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxlQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFFBR0EsdUJBQUMsYUFBUSxXQUFVLHVCQUNqQjtBQUFBLGlDQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsT0FDQztBQUFBLG1DQUFDLFlBQU8sMENBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFTO0FBQUEsZUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxPQUFFLE1BQUssZ0NBQStCLFdBQVUsZUFBYyx3QkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxPQUFFLE1BQUssMENBQXlDLFFBQU8sVUFBUyxLQUFJLHVCQUFzQixXQUFVLGlCQUFnQix3QkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkg7QUFBQSxlQUYvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0VBO0FBQUEsU0E3S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThLQTtBQUFBLE9BbE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvTUEsS0FyTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNNQTtBQUVKO0FBQUNDLEtBMU1LRDtBQTRNTixlQUFlQTtBQUFTLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlBvcnRmb2xpbyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUG9ydGZvbGlvLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgJy4vUG9ydGZvbGlvLmNzcydcblxuY29uc3QgUG9ydGZvbGlvID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicG9ydGZvbGlvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaGVhZGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXItY29udGVudFwiPlxuICAgICAgICAgICAgPGgxPlJveSBFZmZlbmRpZSwgQkEuLCBNU2MuPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRpdGxlXCI+U2VuaW9yIFRlY2huaWNhbCBQcm9ncmFtIE1hbmFnZXI8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIHsvKiBTdW1tYXJ5ICovfVxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzdW1tYXJ5XCI+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBUZWNobmljYWwgUHJvZ3JhbSBNYW5hZ2VyIHdpdGggPHN0cm9uZz4yMisgeWVhcnM8L3N0cm9uZz4gZGVsaXZlcmluZyBjb21wbGV4LCBjcm9zcy1mdW5jdGlvbmFsIHByb2dyYW1zIGluIGZpbnRlY2gsIEFJLCBhbmQgZW50ZXJwcmlzZSBzeXN0ZW1zLlxuICAgICAgICAgICAgUHJvdmVuIHRyYWNrIHJlY29yZCBtYW5hZ2luZyA8c3Ryb25nPiQxMDBNKyBwcm9ncmFtczwvc3Ryb25nPiwgbGVhZGluZyBnbG9iYWwgdGVhbXMgb2YgPHN0cm9uZz41MCsgbWVtYmVyczwvc3Ryb25nPiwgYW5kIGRyaXZpbmcgbWVhc3VyYWJsZSBidXNpbmVzcyBpbXBhY3RcbiAgICAgICAgICAgIHRocm91Z2ggc3RyYXRlZ2ljIHRlY2huaWNhbCBsZWFkZXJzaGlwLiBFeHBlcnQgYXQgYnJpZGdpbmcgYnVzaW5lc3MgYW5kIGVuZ2luZWVyaW5nIHRlYW1zIHdoaWxlIG9yY2hlc3RyYXRpbmcgbXVsdGlwbGUgaGlnaC1zdGFrZXMgaW5pdGlhdGl2ZXMgc2ltdWx0YW5lb3VzbHkuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIFR3byBDb2x1bW4gTGF5b3V0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInR3by1jb2x1bW5cIj5cblxuICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxlZnQtY29sdW1uXCI+XG5cbiAgICAgICAgICAgIHsvKiBFeHBlcmllbmNlICovfVxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2VjdGlvblwiPlxuICAgICAgICAgICAgICA8aDI+RXhwZXJpZW5jZSBIaWdobGlnaHRzPC9oMj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGVyaWVuY2UtaXRlbVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Tci4gRGlyZWN0b3Igb2YgRGV2T3BzL1BsYXRmb3JtIEVuZ2luZWVyaW5nPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ5ZWFyXCI+MjAyNS1QcmVzZW50PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGFueVwiPlVuaXBob3JlLCBQYWxvIEFsdG8sIENBPC9kaXY+XG4gICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgPGxpPkxlZCBwb3N0LWFjcXVpc2l0aW9uIGluZnJhc3RydWN0dXJlIGNvbnNvbGlkYXRpb24gb2YgdHdvIGNvbXBhbmllcywgc3RhbmRhcmRpemluZyBDSS9DRCBwaXBlbGluZXMgYW5kIHBsYXRmb3JtIHRvb2xpbmcgYWNyb3NzIHRoZSBvcmdhbml6YXRpb248L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPlBhcnRuZXJlZCBjcm9zcy1mdW5jdGlvbmFsbHkgd2l0aCBQcm9kdWN0LCBTYWxlcywgRGVsaXZlcnksIGFuZCBJbmZvc2VjIHRvIHNjYWxlIGRlcGxveW1lbnRzIGFjcm9zcyAzIGdsb2JhbCByZWdpb25zIChVUywgVUssIE1pZGRsZSBFYXN0KTwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+RHJvdmUgYWRvcHRpb24gb2Ygc3RhbmRhcmQgS1BJcyBhbmQgdG9vbHMsIGltcHJvdmluZyBzY2hlZHVsZSBwcmVkaWN0YWJpbGl0eSBhbmQgYWNjZWxlcmF0aW5nIHJlbGVhc2UgdmVsb2NpdHkgYnkgMjAlPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT5GYWNpbGl0YXRlZCBjb2xsYWJvcmF0aXZlIHBsYW5uaW5nIHNlc3Npb25zIGFjcm9zcyBidXNpbmVzcyBhbmQgdGVjaG5pY2FsIHN0YWtlaG9sZGVycywgcmVkdWNpbmcgY3Jvc3MtdGVhbSBkZXBlbmRlbmNpZXMgYW5kIGltcHJvdmluZyBtaWxlc3RvbmUgYWNjdXJhY3kgYnkgMjUlPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT5PcHRpbWl6ZWQgY2xvdWQgc3BlbmQgYnkgaWRlbnRpZnlpbmcgaW5lZmZpY2llbmNpZXMsIHJlZHVjaW5nIEFXUyBjb3N0cyBieSAkNDAwSyBhbm51YWxseSB3aGlsZSBjdXR0aW5nIG9wZXJhdGlvbmFsIGNvc3RzIGJ5IDE1JTwvbGk+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBlcmllbmNlLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+U3IuIERpcmVjdG9yIG9mIEN1c3RvbWVyIFNvbHV0aW9uczwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwieWVhclwiPjIwMjItMjAyNTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbXBhbnlcIj5JbmZvd29ya3MgKEFjcXVpcmVkIGJ5IFVuaXBob3JlKTwvZGl2PlxuICAgICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICAgIDxsaT5EaXJlY3RlZCBkZXZlbG9wbWVudCBvZiBTYWFTIEFJIHNvbHV0aW9ucyBsZXZlcmFnaW5nIE9wZW5BSSBMTE1zIHRvIGF1dG9tYXRlIFNRTCBnZW5lcmF0aW9uIGZyb20gbmF0dXJhbCBsYW5ndWFnZSwgdHJhbnNmb3JtaW5nIGVudGVycHJpc2UgZGF0YSB3b3JrZmxvd3M8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkNvbGxhYm9yYXRlZCB3aXRoIEZvcnR1bmUgNTAwIGN1c3RvbWVycyB0byBkZXNpZ24gYW5kIGRlbGl2ZXIgZGF0YSBpbmdlc3Rpb24gYW5kIHBpcGVsaW5lIGF1dG9tYXRpb24gc29sdXRpb25zLCBhY2NlbGVyYXRpbmcgZGV2ZWxvcG1lbnQgYnkgODAlIGFuZCBpbmNyZWFzaW5nIGFkb3B0aW9uIGJ5IDQwJTwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+TGVkIEN1c3RvbWVyIEVuZ2luZWVyaW5nIHRlYW0gaW4gYnVpbGRpbmcgUHl0aG9uIFNES3MgYW5kIGF1dG9tYXRpb24gc2NyaXB0cywgYWNjZWxlcmF0aW5nIGN1c3RvbWVyIG9uYm9hcmRpbmcgYnkgMng8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkVzdGFibGlzaGVkIEtQSXMgYW5kIG9wZXJhdGlvbmFsIHByb2Nlc3NlcyBmb3IgQ3VzdG9tZXIgRW5naW5lZXJpbmcsIFByb2Zlc3Npb25hbCBTZXJ2aWNlcywgYW5kIEZpZWxkLVRlc3RpbmcsIGltcHJvdmluZyBpc3N1ZSByZXNvbHV0aW9uIHRpbWVzIGJ5IDM1JTwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+TWFuYWdlZCB2ZW5kb3Igc2VsZWN0aW9uIGFuZCBjb250cmFjdHMsIGFjaGlldmluZyA5NSUgY3VzdG9tZXIgcmVuZXdhbCByYXRlIHdvcnRoICQxNU0gd2hpbGUgY3V0dGluZyB0aGlyZC1wYXJ0eSBjb3N0cyBieSAyMCU8L2xpPlxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwZXJpZW5jZS1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHAtaGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlNyLiBUZWNobmljYWwgUHJvZ3JhbSBNYW5hZ2VyPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ5ZWFyXCI+MjAyMS0yMDIyPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGFueVwiPlZlbG8gTGFicywgU2FuIEZyYW5jaXNjbywgQ0E8L2Rpdj5cbiAgICAgICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgICA8bGk+T3duZWQgZW5kLXRvLWVuZCBwcm9ncmFtIG1hbmFnZW1lbnQgb2YgY3Jvc3MtYm9yZGVyIHBheW1lbnRzIHBsYXRmb3JtIGxldmVyYWdpbmcgYmxvY2tjaGFpbiB0ZWNobm9sb2d5LCBlbmFibGluZyBmYXN0ZXIsIGxvd2VyLWNvc3QgdHJhbnNhY3Rpb25zIGFjcm9zcyA0KyBjb3VudHJpZXM8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkRlZmluZWQgYW5kIGV4ZWN1dGVkIHByb2R1Y3Qgcm9hZG1hcCBpbiBwYXJ0bmVyc2hpcCB3aXRoIEMtbGV2ZWwgZXhlY3V0aXZlcywgYWxpZ25pbmcgZW5naW5lZXJpbmcsIGNvbXBsaWFuY2UsIGFuZCBidXNpbmVzcyB0ZWFtcyB0byBkZWxpdmVyIHN0cmF0ZWdpYyBnb2FsczwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+U2NhbGVkIGFuZCBsZWQgZ2xvYmFsIHRlYW0gb2YgMzArIGVuZ2luZWVycyBhbmQgcHJvZHVjdCBtYW5hZ2VycywgZXN0YWJsaXNoaW5nIGFnaWxlIHByYWN0aWNlcyBhbmQgaW1wcm92aW5nIG9uLXRpbWUgZGVsaXZlcnkgb2Yga2V5IHJlbGVhc2VzIGJ5IDUwJTwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+RHJvdmUgcGFydG5lciBpbnRlZ3JhdGlvbnMgYnkgZGVmaW5pbmcgdGVjaG5pY2FsIHNjb3BlIGFuZCBsZWFkaW5nIGF1dG9tYXRpb24gaW5pdGlhdGl2ZXMgdGhhdCByZWR1Y2VkIHNldHRsZW1lbnQgdGltZXMgYnkgNzAlIGFuZCBpbmNyZWFzZWQgcGFydG5lciBhZG9wdGlvbiBieSAyNSU8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkRlc2lnbmVkIGFuZCBsZWQgbWlncmF0aW9uIG9mIGZpbmFuY2lhbCBwYXJ0bmVycyB0byBTdGVsbGFyIGJsb2NrY2hhaW4gZWNvc3lzdGVtLCBjdXR0aW5nIGludGVncmF0aW9uIHRpbWVsaW5lcyBmcm9tIDggbW9udGhzIHRvIDQgd2Vla3M8L2xpPlxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwZXJpZW5jZS1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHAtaGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlNlbmlvciBNYW5hZ2VyPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ5ZWFyXCI+MjAxMC0yMDIxPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGFueVwiPkVybnN0ICYgWW91bmcsIFNlYXR0bGUsIFdBPC9kaXY+XG4gICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgPGxpPkxlZCBzdWNjZXNzZnVsIGltcGxlbWVudGF0aW9uIG9mIHRoZSBsYXJnZXN0IHBlcnNvbmFsIGF1dG8gcG9saWN5IHRyYW5zZm9ybWF0aW9uIHByb2dyYW0gaW4gQ2FuYWRhIHdvcnRoICQ3ME0sIG92ZXJzZWVpbmcgMzAwKyBpbnRlZ3JhdGlvbnMgYWNyb3NzIGF1dG8gaW5zdXJhbmNlIHBsYXRmb3JtcywgdmVoaWNsZSByZWdpc3RyYXRpb24gYW5kIGxpY2Vuc2luZyBzeXN0ZW1zPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT5Qcm9ncmFtIHN1Y2Nlc3MgcmVzdWx0ZWQgaW4gYWRkaXRpb25hbCBzY29wZSB0byB0cmFuc2Zvcm0gY29tbWVyY2lhbCBhdXRvLCBnZW5lcmF0aW5nICQzMk0gb2YgbmV3IGNvbnN1bHRpbmcgcmV2ZW51ZSBmb3IgRVk8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkRpcmVjdGVkIGNsYWltcyBkYXRhIGNvbnZlcnNpb24gYW5kIGJhdGNoIGludGVncmF0aW9uIHByb2plY3RzIGF0IGxhcmdlIFVTIGluc3VyZXJzLCBlbmFibGluZyBzZWFtbGVzcyBtaWdyYXRpb24gb2YgbWlsbGlvbnMgb2YgY3VzdG9tZXIgcmVjb3JkcyBhbmQgbWFuYWdpbmcgJDE1TSBvZiBjb25zdWx0aW5nIHJldmVudWU8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkRldmVsb3BlZCBFWSdzIEd1aWRld2lyZSBHbG9iYWwgRGVsaXZlcnkgTWV0aG9kb2xvZ3ksIHRyYWluaW5nIGh1bmRyZWRzIG9mIGNvbnN1bHRhbnRzIHdvcmxkd2lkZSBhbmQgZXN0YWJsaXNoaW5nIHNjYWxhYmxlIHN0YW5kYXJkIGZvciBpbXBsZW1lbnRhdGlvbnM8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPlBpb25lZXJlZCBzb2x1dGlvbnMgbGV2ZXJhZ2luZyBibG9ja2NoYWluLCBJb1QsIGFuZCBtaWNyb3NlcnZpY2VzIHRvIHN1cHBvcnQgaW5ub3ZhdGlvbiBpbml0aWF0aXZlcyBhY3Jvc3MgaW5zdXJhbmNlIGNsaWVudHMsIGdlbmVyYXRpbmcgJDVNIG5ldyBjb25zdWx0aW5nIHJldmVudWUgaW4gZmlyc3QgeWVhcjwvbGk+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBlcmllbmNlLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VGVjaG5pY2FsIEFyY2hpdGVjdCAmIENvbnN1bHRhbnQ8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInllYXJcIj4yMDAyLTIwMTA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb21wYW55XCI+U2V6bWksIEFjY2VudHVyZSwgQmVhcmluZ1BvaW50PC9kaXY+XG4gICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgPGxpPkFyY2hpdGVjdGVkIGFuZCBkZWxpdmVyZWQgZW50ZXJwcmlzZSBDUk0sIGJpbGxpbmcsIGFuZCB2aWRlby1vbi1kZW1hbmQgcGxhdGZvcm1zIHN1cHBvcnRpbmcgMTAwSysgc3Vic2NyaWJlcnM8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkRlc2lnbmVkIGFuZCBidWlsdCBtaWRkbGV3YXJlIHN5c3RlbXMgdG8gcHJvdmlzaW9uIGRpZ2l0YWwga2V5cyBmb3IgbW92aWUgcHVyY2hhc2VzLCByZWR1Y2luZyBwcm92aXNpb25pbmcgZXJyb3JzIGJ5IDgwJTwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+TGVkIGludGVncmF0aW9uIG9mIFNpZWJlbCBDUk0gd2l0aCBDaXRyaXggbGVnYWN5IHN5c3RlbXMsIGltcHJvdmluZyBjdXN0b21lciBkYXRhIHZpc2liaWxpdHkgYWNyb3NzIDIwKyBidXNpbmVzcyB1bml0czwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+RGlyZWN0ZWQgbXVsdGlwbGUgZGF0YSBtaWdyYXRpb24gcHJvamVjdHMsIGNvbnNvbGlkYXRpbmcgbGVnYWN5IHN5c3RlbXMgYW5kIHNhdmluZyBjbGllbnRzICQ4TSsgaW4gSVQgY29zdHMgd2hpbGUgcmVkdWNpbmcgcHJvamVjdCB0aW1lbGluZXMgYnkgMzAlPC9saT5cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIEVkdWNhdGlvbiAqL31cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgPGgyPkVkdWNhdGlvbiAmIENlcnRpZmljYXRpb25zPC9oMj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlZHVjYXRpb24taXRlbVwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+TS5TYy4gRGF0YWJhc2UgRGV2ZWxvcG1lbnQgJiBBZG1pbmlzdHJhdGlvbjwvc3Ryb25nPiDigJQgR29sZGVuIEdhdGUgVW5pdmVyc2l0eVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlZHVjYXRpb24taXRlbVwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+Qi5BLiBFY29ub21pY3M8L3N0cm9uZz4g4oCUIFBhcmFoeWFuZ2FuIENhdGhvbGljIFVuaXZlcnNpdHlcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWR1Y2F0aW9uLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPkFXUyBDZXJ0aWZpZWQgQ2xvdWQgUHJhY3RpdGlvbmVyPC9zdHJvbmc+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmlnaHQgQ29sdW1uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlnaHQtY29sdW1uXCI+XG5cbiAgICAgICAgICAgIHsvKiBDb3JlIFN0cmVuZ3RocyAqL31cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNlY3Rpb25cIj5cbiAgICAgICAgICAgICAgPGgyPkNvcmUgU3RyZW5ndGhzPC9oMj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdHJlbmd0aC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz7wn46vIE11bHRpLVByb2plY3QgT3JjaGVzdHJhdGlvbjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDxwPlN1Y2Nlc3NmdWxseSBtYW5hZ2VkIDMwMCsgY29uY3VycmVudCBpbnRlZ3JhdGlvbnMgYWNyb3NzIGVudGVycHJpc2UgcGxhdGZvcm1zPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdHJlbmd0aC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz7wn6SWIEFJLURyaXZlbiBJbm5vdmF0aW9uPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPHA+TGV2ZXJhZ2VkIE9wZW5BSS9MTE1zIHRvIGFjY2VsZXJhdGUgZGV2ZWxvcG1lbnQgYnkgODAlIGFuZCBpbXByb3ZlIHByb2R1Y3Rpdml0eTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RyZW5ndGgtaXRlbVwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+8J+MiSBCdXNpbmVzcy1UZWNoIEJyaWRnZTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDxwPlBhcnRuZXIgYWNyb3NzIFByb2R1Y3QsIEVuZ2luZWVyaW5nLCBTYWxlcywgYW5kIEMtc3VpdGUgdG8gYWxpZ24gc3RyYXRlZ2ljIGluaXRpYXRpdmVzPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdHJlbmd0aC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz7imqEgRmFzdCBMZWFybmVyPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPHA+RGl2ZXJzZSBiYWNrZ3JvdW5kIGluIGRhdGFiYXNlLCB3ZWIgZGV2LCBhbmQgc3lzdGVtIGludGVncmF0aW9uLiBRdWlja2x5IG1hc3RlciBuZXcgdGVjaG5vbG9naWVzPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIFRlY2huaWNhbCBTa2lsbHMgKi99XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzZWN0aW9uXCI+XG4gICAgICAgICAgICAgIDxoMj5UZWNobmljYWwgU2tpbGxzPC9oMj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNraWxsLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5DbG91ZCAmIEluZnJhc3RydWN0dXJlOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDxwPkFXUywgQXp1cmUsIEdDUCwgS3ViZXJuZXRlcywgRG9ja2VyLCBDSS9DRDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+QUkgJiBEYXRhOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDxwPk9wZW5BSS9MTE1zLCBTbm93Zmxha2UsIERhdGFicmlja3MsIEthZmthLCBTcGFyazwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+QmxvY2tjaGFpbjo8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8cD5TdGVsbGFyLCBCU0MsIFdlYjMsIFNtYXJ0IENvbnRyYWN0czwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+RGV2ZWxvcG1lbnQ6PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPHA+UHl0aG9uLCBKYXZhU2NyaXB0LCBSZWFjdCwgTm9kZS5qcywgR29sYW5nLCBTUUw8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tpbGwtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPkRhdGFiYXNlczo8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8cD5PcmFjbGUsIFNRTCBTZXJ2ZXIsIFBvc3RncmVTUUwsIE5vU1FMPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNraWxsLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5QTSBUb29sczo8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8cD5KSVJBLCBDb25mbHVlbmNlLCBBZ2lsZS9TY3J1bSwgTVMgUHJvamVjdDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgIHsvKiBUYXJnZXQgUm9sZSAqL31cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNlY3Rpb24gdGFyZ2V0LXJvbGVcIj5cbiAgICAgICAgICAgICAgPGgyPlNlZWtpbmc8L2gyPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPlNlbmlvciBUUE0gcm9sZXMgYXQgJDIyNUsrPC9zdHJvbmc+IGluIHRlY2ggY29tcGFuaWVzIHdoZXJlIEkgY2FuIGRyaXZlIHN0cmF0ZWdpY1xuICAgICAgICAgICAgICAgIHRlY2huaWNhbCBpbml0aWF0aXZlcywgb3JjaGVzdHJhdGUgY29tcGxleCBjcm9zcy1mdW5jdGlvbmFsIHByb2dyYW1zLCBhbmQgZGVsaXZlclxuICAgICAgICAgICAgICAgIG1lYXN1cmFibGUgYnVzaW5lc3MgaW1wYWN0IGF0IHNjYWxlLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3RhLWJ1dHRvbnNcIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwibWFpbHRvOnJlZmZlbmRpZUBvdXRsb29rLmNvbVwiIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCI+RW1haWwgTWU8L2E+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS9pbi9yZWZmZW5kaWUvXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIj5MaW5rZWRJbjwvYT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFBvcnRmb2xpb1xuIl0sImZpbGUiOiIvVXNlcnMvcm95ZWZmZW5kaWUvUHJvamVjdHMvcG9ydGZvbGlvL3NyYy9jb21wb25lbnRzL1BvcnRmb2xpby5qc3gifQ==