import {
  require_react
} from "/node_modules/.vite/deps/chunk-3ON3CNAS.js?v=dfdfbf81";
export default require_react();
//# sourceMappingURL=react.js.map
